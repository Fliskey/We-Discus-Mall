package com.mallBuilding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
