package com.mallBuilding.service;

import com.mallBuilding.entity.GmGoods;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author admin
 * @since 2021-07-06
 */
public interface GmGoodsService extends IService<GmGoods> {

}
