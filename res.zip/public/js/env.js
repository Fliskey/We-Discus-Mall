// 配置编译环境和线上环境之间的切换

var baseUrl = '/';
window.urlConfig = {
    baseUrl: baseUrl,
}
