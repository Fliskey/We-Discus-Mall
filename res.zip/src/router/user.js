/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2021-07-02 15:29:31
 * @version $Id$ 组织者登录
 */

export default [
  {
    path: '/login',
    component: () =>
      import('@/page/login/index')
  }
]